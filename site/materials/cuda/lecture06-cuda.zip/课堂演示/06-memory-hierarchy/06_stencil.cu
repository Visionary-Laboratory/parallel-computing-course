#include "lab06_utils.cuh"
// Contract: zero extension outside [0,n), denominator always 2*R+1, disjoint x/y.
// This executable uses only bounded int indices, block size 256, default stream.
// Override with -DSTENCIL_RADIUS=2 to reproduce the small teaching window.
#ifndef STENCIL_RADIUS
#define STENCIL_RADIUS 32
#endif
constexpr int B=256, R=STENCIL_RADIUS;
static_assert(R>=1 && R<=64, "This classroom example supports radii 1..64");
__global__ void stencil_naive(const float* x,float* y,int n) {
    int i=int(blockIdx.x)*B+int(threadIdx.x);
    if(i>=n) return;
    float sum=0;
    for(int d=-R;d<=R;++d) {
        int j=i+d;
        if(j>=0&&j<n) sum+=x[j];
    }
    y[i]=sum / float(2*R+1);
}
__global__ void stencil_shared(const float* x,float* y,int n) {
    __shared__ float tile[B+2*R];
    int t=int(threadIdx.x),base=int(blockIdx.x)*B;
    for(int j=t;j<B+2*R;j+=B) {
        int g=base+j-R;
        tile[j]=(g>=0&&g<n)?x[g]:0.0f;
    }
    __syncthreads();
    int i=base+t;
    if(i<n) {
        float sum=0;
        for(int d=0;d<2*R+1;++d) sum+=tile[t+d];
        y[i]=sum / float(2*R+1);
    }
}
// Measure the same input, radius, output count, and number of launches.
// Alternate naive/shared order across five batches to reduce order bias.
template<class F, class G>
void compare_kernels(F naive, G shared, int repeats) {
    for(int i=0;i<20;++i) { naive(); shared(); }
    CUDA_CHECK(cudaGetLastError()); CUDA_CHECK(cudaDeviceSynchronize());
    cudaEvent_t start,stop;
    CUDA_CHECK(cudaEventCreate(&start)); CUDA_CHECK(cudaEventCreate(&stop));
    auto measure=[&](auto launch) {
        CUDA_CHECK(cudaEventRecord(start));
        for(int i=0;i<repeats;++i) launch();
        CUDA_CHECK(cudaGetLastError()); CUDA_CHECK(cudaEventRecord(stop));
        CUDA_CHECK(cudaEventSynchronize(stop));
        float ms=0; CUDA_CHECK(cudaEventElapsedTime(&ms,start,stop));
        return ms/repeats;
    };
    std::array<float,5> a{},b{};
    for(int batch=0;batch<5;++batch) {
        if(batch%2==0) { a[batch]=measure(naive); b[batch]=measure(shared); }
        else { b[batch]=measure(shared); a[batch]=measure(naive); }
    }
    CUDA_CHECK(cudaEventDestroy(start)); CUDA_CHECK(cudaEventDestroy(stop));
    std::sort(a.begin(),a.end()); std::sort(b.begin(),b.end());
    std::printf("naive  : %.6f ms (min %.6f, max %.6f)\n",a[2],a[0],a[4]);
    std::printf("shared : %.6f ms (min %.6f, max %.6f)\n",b[2],b[0],b[4]);
    std::printf("Speedup: %.2fx (naive / shared; median of 5 alternating batches, %d calls/batch)\n",a[2]/b[2],repeats);
}
void run(int n,int repeats=0) {
    require(n>=0&&n<=(1<<24),"This example requires 0 <= n <= 2^24");
    std::printf("N=%d, R=%d, window=%d\n",n,R,2*R+1);
    std::vector<float> x(n);
    for(int i=0;i<n;++i) x[i]=float((i%37)-18)*0.125f;
    // Independent reference: visit each input and contribute to valid outputs.
    std::vector<double> ref(n,0.0);
    for(int j=0;j<n;++j)
        for(int i=std::max(0,j-R);i<=std::min(n-1,j+R);++i) ref[i]+=double(x[j])/double(2*R+1);
    DeviceBuffer<float> dx(n),dy(n);dx.upload(x);
    for(int mode=0;mode<2;++mode) {
        auto launch=[&] {
            if(!n) return;
            if(mode==0) stencil_naive<<<(n+B-1)/B,B>>>(dx.p,dy.p,n);
            else stencil_shared<<<(n+B-1)/B,B>>>(dx.p,dy.p,n);
        };
        // Poison catches missing writes even if the allocation previously held valid output.
        if(n) CUDA_CHECK(cudaMemset(dy.p,0xff,size_t(n)*sizeof(float)));
        launch();CUDA_CHECK(cudaGetLastError());CUDA_CHECK(cudaDeviceSynchronize());
        auto worst=check_close(dy.download(),ref,2e-6,2e-6);
        std::printf("stencil_%s,n=%d,max_abs_error=%.4g,PASS\n",mode?"shared":"naive",n,worst);

    }
    if(repeats&&n) compare_kernels(
        [&]{stencil_naive<<<(n+B-1)/B,B>>>(dx.p,dy.p,n);},
        [&]{stencil_shared<<<(n+B-1)/B,B>>>(dx.p,dy.p,n);}, repeats);
}
int main(int argc,char** argv) {
    if(argc==2&&!std::strcmp(argv[1],"--help")) {
        std::puts("stencil.exe [N [repeats]] | --check-only\nN: 0..16777216; repeats: 1..10000; defaults: 4194304 100\nRadius: 32 by default; compile with -DSTENCIL_RADIUS=2 for the 5-point case.\nTiming: kernel only, 20 warm-up calls per variant, 5 alternating batches; copies and CPU checks excluded.");return 0;
    }
    bool check_only=argc==2&&!std::strcmp(argv[1],"--check-only");
    require(check_only||argc==1||argc==2||argc==3,"Usage: stencil.exe [N [repeats]] | --check-only | --help");
    int n=1<<22,repeats=100;
    if(!check_only&&argc>=2)n=lab06_int(argv[1],0,1<<24);
    if(argc==3)repeats=lab06_int(argv[2],1,10000);
    device_info();
    lab06_resources("stencil_naive",stencil_naive,B);
    lab06_resources("stencil_shared",stencil_shared,B);
    if(check_only)for(int size:{0,1,2,3,5,31,32,33,63,64,65,255,256,257,1003})run(size);
    else run(n,repeats);
}

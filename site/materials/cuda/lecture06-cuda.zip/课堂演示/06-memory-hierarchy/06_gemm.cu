#include "lab06_utils.cuh"

// Row-major A[M,K] * B[K,N] = C[M,N]. FP32, no Tensor Cores or cuBLAS.
constexpr int T = 16;  // Output tile: T rows by T columns; block(T, T).
constexpr int TK = 16; // Number of K terms loaded and accumulated per stage.
// This teaching version loads one A and one B element per thread.
static_assert(T == TK, "The one-element-per-thread loader requires T == TK.");
__global__ void gemm_naive(const float* A, const float* B, float* C, int M, int N, int K) {
    int row = blockIdx.y * T + threadIdx.y, col = blockIdx.x * T + threadIdx.x;
    if (row < M && col < N) {
        float acc = 0;
        for (int k = 0; k < K; ++k)
            acc = fmaf(A[size_t(row) * K + k], B[size_t(k) * N + col], acc);
        C[size_t(row) * N + col] = acc;
    }
}
__global__ void gemm_tiled(const float* A, const float* B, float* C, int M, int N, int K) {
    __shared__ float As[T][TK], Bs[TK][T];
    int tx = threadIdx.x, ty = threadIdx.y;
    int row = blockIdx.y * T + ty, col = blockIdx.x * T + tx;
    float acc = 0;
    for (int base = 0; base < K; base += TK) { // base: this stage's starting K index.
        As[ty][tx] = (row < M && base + tx < K) ? A[size_t(row) * K + base + tx] : 0.0f;
        Bs[ty][tx] = (base + ty < K && col < N) ? B[size_t(base + ty) * N + col] : 0.0f;
        __syncthreads(); // This stage's inputs are ready.
        for (int k = 0; k < TK; ++k) // Local K index; global K index is base + k.
            acc = fmaf(As[ty][k], Bs[k][tx], acc);
        __syncthreads(); // All readers finish before the next stage overwrites the tile.
    }
    if (row < M && col < N) C[size_t(row) * N + col] = acc;
}
void run(int M, int N, int K, int repeats = 0) {
    if (!M || !N) { std::puts("Empty GEMM output: launch skipped; PASS"); return; }
    std::vector<float> A(size_t(M) * K), B(size_t(K) * N);
    std::vector<double> ref(size_t(M) * N, 0);
    for (size_t i = 0; i < A.size(); ++i) A[i] = float(int(i % 29) - 14) / 17.0f;
    for (size_t i = 0; i < B.size(); ++i) B[i] = float(int(i % 31) - 15) / 19.0f;
    // CPU FP64 reference, outside kernel timing; loop order differs from GPU.
    for (int r = 0; r < M; ++r) for (int k = 0; k < K; ++k) for (int c = 0; c < N; ++c)
        ref[size_t(r) * N + c] += double(A[size_t(r) * K + k]) * double(B[size_t(k) * N + c]);
    DeviceBuffer<float> da(A.size()), db(B.size()), dc(ref.size());
    da.upload(A); db.upload(B);
    dim3 block(T, T), grid((N + T - 1) / T, (M + T - 1) / T);
    for (int mode = 0; mode < 2; ++mode) {
        const char* name = mode ? "gemm_tiled16" : "gemm_naive";
        auto launch = [&] {
            if (!mode) gemm_naive<<<grid, block>>>(da.p, db.p, dc.p, M, N, K);
            else gemm_tiled<<<grid, block>>>(da.p, db.p, dc.p, M, N, K);
        };
        CUDA_CHECK(cudaMemset(dc.p, 0xff, ref.size() * sizeof(float)));
        launch(); CUDA_CHECK(cudaGetLastError()); CUDA_CHECK(cudaDeviceSynchronize());
        double error = check_close(dc.download(), ref, 2e-4, 2e-4);
        std::printf("%s,M=%d,N=%d,K=%d,max_abs_error=%.5g,PASS\n", name, M, N, K, error);
        if (repeats) {
            float ms = benchmark(name, launch, repeats);
            std::printf("RESULT,gemm,%s,%d,%d,%d,%.6f,%.3f\n", name, M, N, K, ms, 2.0 * M * N * K / (ms * 1e6));
        }
    }
}
int main(int argc, char** argv) {
    if (argc == 2 && !std::strcmp(argv[1], "--help")) {
        std::puts("gemm.exe [M N K [repeats]] | --check-only\nM,N,K: 0..1024; repeats: 1..10000; defaults: 512 512 512 20\nRESULT fields: workload,variant,M,N,K,median_ms,GFLOP/s (2*M*N*K)");
        return 0;
    }
    bool check_only = argc == 2 && !std::strcmp(argv[1], "--check-only");
    require(check_only || argc == 1 || argc == 4 || argc == 5, "Usage: gemm.exe [M N K [repeats]] | --check-only | --help");
    int M = 512, N = 512, K = 512, repeats = 20;
    if (argc >= 4) { M = lab06_int(argv[1], 0, 1024); N = lab06_int(argv[2], 0, 1024); K = lab06_int(argv[3], 0, 1024); }
    if (argc == 5) repeats = lab06_int(argv[4], 1, 10000);
    device_info();
    lab06_resources("gemm_naive", gemm_naive, T * T);
    lab06_resources("gemm_tiled16", gemm_tiled, T * T);
    if (check_only) {
        const std::array<int,3> cases[] = {{0,7,3}, {7,0,3}, {1,1,1}, {3,5,0}, {17,33,19}, {63,65,31}, {1,127,65}, {16,16,18}};
        for (auto d : cases)
            run(d[0], d[1], d[2]);
    } else run(M, N, K, repeats);
}

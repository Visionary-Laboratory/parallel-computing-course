#include "lab06_utils.cuh"
// Introductory version: block(32,32), one element per thread.
__global__ void copy_matrix(const float* a,float* b,int m,int n) {
    int x=blockIdx.x*32+threadIdx.x,y=blockIdx.y*32+threadIdx.y;
    if(x<n&&y<m) b[size_t(y)*n+x]=a[size_t(y)*n+x];
}
__global__ void naive(const float* a,float* b,int m,int n) {
    int x=blockIdx.x*32+threadIdx.x,y=blockIdx.y*32+threadIdx.y;
    if(x<n&&y<m) b[size_t(x)*m+y]=a[size_t(y)*n+x];
}
template<int Pitch> __global__ void tiled(const float* a,float* b,int m,int n) {
    __shared__ float tile[32][Pitch];
    int tx=threadIdx.x,ty=threadIdx.y;
    int x=blockIdx.x*32+tx,y=blockIdx.y*32+ty;
    if(x<n&&y<m) tile[ty][tx]=a[size_t(y)*n+x];
    __syncthreads();
    int out_x=blockIdx.y*32+tx,out_y=blockIdx.x*32+ty;
    if(out_x<m&&out_y<n) b[size_t(out_y)*m+out_x]=tile[tx][ty];
}
void run(int m,int n,int repeats=0) {
    size_t count=size_t(m)*n;std::vector<float>a(count);std::vector<double>ref(count),copy_ref(count);
    for(int r=0;r<m;++r)for(int c=0;c<n;++c){
        float v=float((size_t(r)*n+c)%100003)*0.125f;
        a[size_t(r)*n+c]=v;ref[size_t(c)*m+r]=v;copy_ref[size_t(r)*n+c]=v;
    }
    if(!count){std::puts("Empty transpose: launch skipped; PASS");return;}
    DeviceBuffer<float>da(count),db(count);da.upload(a);
    dim3 block(32,32),grid((n+31)/32,(m+31)/32);
    for(int mode=0;mode<4;++mode){
        const char* name=mode==0?"copy":mode==1?"naive":mode==2?"shared32":"padded33";
        auto launch=[&]{
            if(mode==0)copy_matrix<<<grid,block>>>(da.p,db.p,m,n);
            if(mode==1)naive<<<grid,block>>>(da.p,db.p,m,n);
            if(mode==2)tiled<32><<<grid,block>>>(da.p,db.p,m,n);
            if(mode==3)tiled<33><<<grid,block>>>(da.p,db.p,m,n);
        };
        // Poison output so omitted writes cannot accidentally match a previous version.
        CUDA_CHECK(cudaMemset(db.p,0xff,count*sizeof(float)));
        launch();CUDA_CHECK(cudaGetLastError());CUDA_CHECK(cudaDeviceSynchronize());
        check_close(db.download(),mode==0?copy_ref:ref,0,0);
        std::printf("%s,M=%d,N=%d,PASS\n",name,m,n);
        if(repeats){float ms=benchmark(name,launch,repeats);std::printf("RESULT,transpose,%s,%d,%d,%.6f,%.3f\n",name,m,n,ms,8.0*count/(ms*1e6));}
    }
}
int main(int argc,char** argv){
    if(argc==2&&!std::strcmp(argv[1],"--help")) {
        std::puts("transpose.exe [M N [repeats]] | --check-only\nM,N: 0..8192; repeats: 1..10000; defaults: 4096 4096 20\nRESULT fields: workload,variant,M,N,median_ms,logical_GBps (8*M*N bytes)");return 0;
    }
    bool check_only=argc==2&&!std::strcmp(argv[1],"--check-only");
    require(check_only||argc==1||argc==3||argc==4,"Usage: transpose.exe [M N [repeats]] | --check-only | --help");
    int m=4096,n=4096,repeats=20;
    if(argc>=3){m=lab06_int(argv[1],0,8192);n=lab06_int(argv[2],0,8192);}
    if(argc==4)repeats=lab06_int(argv[3],1,10000);
    device_info();
    lab06_resources("naive",naive,1024);
    lab06_resources("shared32",tiled<32>,1024);
    lab06_resources("padded33",tiled<33>,1024);
    const std::array<int,2> cases[]={{0,7},{7,0},{1,1},{1,65},{37,65},{65,37},{32,32},{257,1003}};
    if(check_only){for(auto d:cases)run(d[0],d[1]);}
    else run(m,n,repeats);
}

#include "lab06_utils.cuh"
#include <chrono>

// One thread synthesizes one sample. terms is the number of sine components.
__global__ void synthesize(const float* x, float* y, int n, int terms) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;
    float sum = 0.0f;
    for (int k = 1; k <= terms; ++k)
        sum += sinf(k * x[i]) / k;
    y[i] = sum;
}

// Three equal data chunks for ALL configurations; only stream assignment changes.
// h_in/h_out are pinned arrays of 3*chunk_size floats; d_in/d_out are device arrays.
// streams[0..stream_count-1] have already been created. No hidden chunk helper.
void run_pipeline(const float* h_in, float* h_out, float* d_in, float* d_out,
                  int chunk_size, int terms, cudaStream_t* streams, int stream_count) {
    size_t bytes = size_t(chunk_size) * sizeof(float);
    for (int c = 0; c < 3; ++c) { // Submit all uploads first.
        int offset = c * chunk_size;
        CUDA_CHECK(cudaMemcpyAsync(d_in + offset, h_in + offset, bytes,
            cudaMemcpyHostToDevice, streams[c % stream_count]));
    }
    for (int c = 0; c < 3; ++c) { // Then submit all kernels.
        int offset = c * chunk_size;
        synthesize<<<(chunk_size + 255) / 256, 256, 0,
            streams[c % stream_count]>>>(d_in + offset, d_out + offset, chunk_size, terms);
        CUDA_CHECK(cudaGetLastError());
    }
    for (int c = 0; c < 3; ++c) { // Finally submit all downloads.
        int offset = c * chunk_size;
        CUDA_CHECK(cudaMemcpyAsync(h_out + offset, d_out + offset, bytes,
            cudaMemcpyDeviceToHost, streams[c % stream_count]));
    }
    for (int s = 0; s < stream_count; ++s)
        CUDA_CHECK(cudaStreamSynchronize(streams[s]));
}

// CPU FP64 reference for the 1024 distinct phases used in the input.
// Every output is checked; periodic input avoids repeating CPU transcendental work.
std::vector<double> reference_signal(int terms) {
    std::vector<double> ref(1024, 0.0);
    for (int p = 0; p < 1024; ++p) {
        double phase = double(float(p) * 0.006f);
        for (int k = 1; k <= terms; ++k) ref[p] += std::sin(k * phase) / k;
    }
    return ref;
}
void verify_signal(const float* out, int n, const std::vector<double>& ref) {
    for (int i = 0; i < n; ++i) {
        double expected = ref[i % 1024];
        require(std::isfinite(out[i]) && std::abs(out[i] - expected) <= 1e-5 + 1e-5 * std::abs(expected),
                "signal result mismatch");
    }
}

void run(int chunk_size, int terms, bool timed) {
    int n = 3 * chunk_size;
    size_t total_bytes = size_t(n) * sizeof(float);
    float *h_in, *h_out, *d_in, *d_out;
    CUDA_CHECK(cudaMallocHost(&h_in, total_bytes));
    CUDA_CHECK(cudaMallocHost(&h_out, total_bytes));
    CUDA_CHECK(cudaMalloc(&d_in, total_bytes));
    CUDA_CHECK(cudaMalloc(&d_out, total_bytes));
    for (int i = 0; i < n; ++i) h_in[i] = float(i % 1024) * 0.006f;
    cudaStream_t streams[3];
    for (int s = 0; s < 3; ++s)
        CUDA_CHECK(cudaStreamCreateWithFlags(&streams[s], cudaStreamNonBlocking));
    auto ref = reference_signal(terms);

    // Test each assignment independently, including missing-write detection.
    for (int count : {1, 3}) {
        std::fill(h_out, h_out + n, NAN);
        CUDA_CHECK(cudaMemset(d_out, 0xff, total_bytes));
        CUDA_CHECK(cudaDeviceSynchronize());
        run_pipeline(h_in, h_out, d_in, d_out, chunk_size, terms, streams, count);
        verify_signal(h_out, n, ref);
    }
    if (timed) {
        for (int warm = 0; warm < 5; ++warm)
            for (int count : {1, 3})
                run_pipeline(h_in, h_out, d_in, d_out, chunk_size, terms, streams, count);
        const int counts[2] = {1, 3};
        double ms[2][9];
        for (int trial = 0; trial < 9; ++trial) {
            for (int j = 0; j < 2; ++j) {
                int mode = (trial + j) % 2; // Alternate which configuration runs first.
                auto start = std::chrono::steady_clock::now();
                run_pipeline(h_in, h_out, d_in, d_out, chunk_size, terms, streams, counts[mode]);
                auto stop = std::chrono::steady_clock::now();
                ms[mode][trial] = std::chrono::duration<double, std::milli>(stop - start).count();
                verify_signal(h_out, n, ref); // Outside the timed interval.
            }
        }
        for (int mode = 0; mode < 2; ++mode) std::sort(ms[mode], ms[mode] + 9);
        std::printf("chunks=3, chunk_size=%d, total_N=%d, terms=%d\n", chunk_size, n, terms);
        for (int mode = 0; mode < 2; ++mode)
            std::printf("%d stream(s): PASS, total=%.3f ms, speedup=%.2fx (min %.3f, max %.3f)\n",
                        counts[mode], ms[mode][4], ms[0][4] / ms[mode][4], ms[mode][0], ms[mode][8]);
    } else std::printf("chunk_size=%d, terms=%d: 1/3 streams PASS\n", chunk_size, terms);

    for (int s = 0; s < 3; ++s) CUDA_CHECK(cudaStreamDestroy(streams[s]));
    CUDA_CHECK(cudaFree(d_in)); CUDA_CHECK(cudaFree(d_out));
    CUDA_CHECK(cudaFreeHost(h_in)); CUDA_CHECK(cudaFreeHost(h_out));
}

// A separate minimal example of a dependency across streams: input -> +1 -> +1.
__global__ void add_one(const float* x, float* y, int n) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) y[i] = x[i] + 1.0f;
}
void check_event_dependency() {
    const int n = 1003;
    std::vector<float> input(n);
    for (int i = 0; i < n; ++i) input[i] = float(i % 97) - 48.0f;
    DeviceBuffer<float> a(n), b(n); a.upload(input);
    CUDA_CHECK(cudaMemset(b.p, 0xff, n * sizeof(float)));
    CUDA_CHECK(cudaDeviceSynchronize());
    cudaStream_t s0, s1; cudaEvent_t ready;
    CUDA_CHECK(cudaStreamCreateWithFlags(&s0, cudaStreamNonBlocking));
    CUDA_CHECK(cudaStreamCreateWithFlags(&s1, cudaStreamNonBlocking));
    CUDA_CHECK(cudaEventCreateWithFlags(&ready, cudaEventDisableTiming));
    add_one<<<(n + 255) / 256, 256, 0, s0>>>(a.p, b.p, n);
    CUDA_CHECK(cudaGetLastError());
    CUDA_CHECK(cudaEventRecord(ready, s0));
    CUDA_CHECK(cudaStreamWaitEvent(s1, ready, 0));
    add_one<<<(n + 255) / 256, 256, 0, s1>>>(b.p, a.p, n);
    CUDA_CHECK(cudaGetLastError());
    CUDA_CHECK(cudaStreamSynchronize(s1));
    auto output = a.download();
    for (int i = 0; i < n; ++i) require(output[i] == input[i] + 2.0f, "event result mismatch");
    CUDA_CHECK(cudaEventDestroy(ready));
    CUDA_CHECK(cudaStreamDestroy(s0)); CUDA_CHECK(cudaStreamDestroy(s1));
    std::puts("event dependency: PASS (input + 2)");
}

int main(int argc, char** argv) {
    if (argc == 2 && !std::strcmp(argv[1], "--help")) {
        std::puts("stream.exe [chunk_size [terms]] | --check-only\nchunk_size: 1..4194304, default 1048576; total N = 3 * chunk_size.\nterms: 1..256, default 64. Same three chunks and kernel for 1/3 streams.\n5 warmups per mode, 9 alternating-order trials; median host total-time.\nIncludes uploads, kernels, downloads and waits. Excludes allocations and validation.");
        return 0;
    }
    if (argc == 2 && !std::strcmp(argv[1], "--check-only")) {
        for (int size : {1, 2, 3, 31, 255, 256, 257, 1003})
            for (int terms : {1, 3, 64, 256}) run(size, terms, false);
    } else {
        require(argc <= 3, "Usage: stream.exe [chunk_size [terms]] | --check-only | --help");
        int size = argc >= 2 ? lab06_int(argv[1], 1, 4194304) : 1048576;
        int terms = argc == 3 ? lab06_int(argv[2], 1, 256) : 64;
        run(size, terms, true);
    }
    check_event_dependency();
}

#pragma once
#include "common.cuh"
#include <cerrno>
#include <cstring>

// Host-side helpers, not CUDA keywords.
inline int lab06_int(const char* text, int low, int high) {
    char* end = nullptr;
    errno = 0;
    long value = std::strtol(text, &end, 10);
    require(errno == 0 && end != text && *end == '\0' && value >= low && value <= high,
            "Invalid integer argument (see --help for supported ranges).");
    return int(value);
}
template<class Kernel>
void lab06_resources(const char* name, Kernel kernel, int threads) {
    cudaFuncAttributes attr{};
    int active = 0;
    CUDA_CHECK(cudaFuncGetAttributes(&attr, kernel));
    CUDA_CHECK(cudaOccupancyMaxActiveBlocksPerMultiprocessor(&active, kernel, threads, 0));
    std::printf("resources,%s,threads=%d,registers_per_thread=%d,static_shared_bytes=%zu,active_blocks_per_SM=%d\n",
                name, threads, attr.numRegs, attr.sharedSizeBytes, active);
}

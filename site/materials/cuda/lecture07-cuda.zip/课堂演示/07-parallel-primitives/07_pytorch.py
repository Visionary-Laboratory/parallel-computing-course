"""Lecture 07: small PyTorch examples of CUDA parallel primitives.

Run in an environment with PyTorch installed:
    python 07_pytorch.py             # all examples, CUDA by default
    python 07_pytorch.py scan        # one example
    python 07_pytorch.py --device cpu

These examples demonstrate output semantics, not PyTorch's internal kernels.
Host reads below are for display and validation; this is not a benchmark.
"""

import argparse
import torch


def show(label, result, expected):
    """Display a scalar/list and check the hand-computed classroom result."""
    value = result.tolist()
    print(f"  {label}: {value}")
    if value != expected:
        raise AssertionError(f"{label}: expected {expected}, got {value}")


def reduce_example(device):
    x = torch.tensor([[1., 2., 3.], [4., 5., 6.]], device=device)
    show("sum all", torch.sum(x), 21.0)
    show("sum dim=0", torch.sum(x, dim=0), [5., 7., 9.])
    show("sum dim=1", torch.sum(x, dim=1), [6., 15.])
    show("sum dim=1, keepdim", torch.sum(x, dim=1, keepdim=True), [[6.], [15.]])
    show("mean all", torch.mean(x), 3.5)
    show("amax dim=1", torch.amax(x, dim=1), [3., 6.])


def scan_example(device):
    x = torch.tensor([3, 1, 0, 2, 4, 0, 1, 1], device=device)
    inclusive = torch.cumsum(x, dim=0)
    # For these small integers only; not a general floating-point scan recipe.
    exclusive = inclusive - x
    show("inclusive", inclusive, [3, 4, 4, 6, 10, 10, 11, 12])
    show("exclusive", exclusive, [0, 3, 4, 4, 6, 10, 10, 11])


def compact_example(device):
    x = torch.tensor([2, -1, 5, 0, 3, -4], device=device)
    mask = x > 0
    show("mask", mask, [True, False, True, False, True, False])
    show("x[mask]", x[mask], [2, 5, 3])
    show("masked_select", torch.masked_select(x, mask), [2, 5, 3])
    show("where(mask, x, 0)", torch.where(mask, x, 0), [2, 0, 5, 0, 3, 0])


def hist_example(device):
    labels = torch.tensor([1, 0, 1, 3, 1, 0, 2, 1], device=device)
    counts = torch.bincount(labels, minlength=4)
    show("bincount", counts, [2, 4, 1, 1])


def gather_example(device):
    x = torch.tensor([10, 20, 30, 40], device=device)
    index = torch.tensor([2, 0, 2], device=device)
    show("index_select", torch.index_select(x, 0, index), [30, 10, 30])
    src = torch.tensor([1, 2, 3], device=device)
    out = torch.zeros(4, dtype=torch.int64, device=device)
    out.scatter_add_(0, index, src)
    show("scatter_add_", out, [2, 0, 4, 0])


EXAMPLES = {
    "reduce": reduce_example,
    "scan": scan_example,
    "compact": compact_example,
    "hist": hist_example,
    "gather": gather_example,
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("example", nargs="?", default="all", choices=["all", *EXAMPLES])
    parser.add_argument("--device", choices=["cuda", "cpu"], default="cuda")
    args = parser.parse_args()
    if args.device == "cuda" and not torch.cuda.is_available():
        parser.error("CUDA is unavailable. Use GPU-enabled PyTorch, or pass --device cpu.")
    device_name = torch.cuda.get_device_name(0) if args.device == "cuda" else "CPU"
    print(f"PyTorch {torch.__version__} | {device_name}")
    selected = EXAMPLES if args.example == "all" else {args.example: EXAMPLES[args.example]}
    for name, run in selected.items():
        print(f"[{name}]")
        run(args.device)
    print("PASS: all displayed results match the classroom examples.")


if __name__ == "__main__":
    main()

#include "common.cuh"
#include <cub/cub.cuh>
#include <memory>
#include <cstring>
#include <cerrno>
// Baseline: the same grid-stride work as reduce_sum, followed by a shared tree.
__global__ void reduce_shared(const float* x, float* partial, size_t n) {
    __shared__ float s[256];
    unsigned t = threadIdx.x;
    float local = 0;
    for (size_t i = size_t(blockIdx.x)*256+t; i < n; i += size_t(gridDim.x)*256)
        local += x[i];
    s[t] = local;
    __syncthreads();
    for (unsigned d = 128; d > 0; d >>= 1) {
        if (t < d) s[t] += s[t+d];
        __syncthreads();
    }
    if (t == 0) partial[blockIdx.x] = s[0];
}
__global__ void reduce_sum(const float* x, float* partial, size_t n) {
    float local = 0;
    for (size_t i = size_t(blockIdx.x)*256+threadIdx.x;
         i < n; i += size_t(gridDim.x)*256)
        local += x[i];
    float sum = block_reduce<false>(local);
    if (threadIdx.x == 0) partial[blockIdx.x] = sum;
}
// One block per row, exactly 256 columns: every thread loads one input.
__global__ void row_sum_shared(const float* x, float* out) {
    unsigned t = threadIdx.x;
    size_t row = blockIdx.x;
    __shared__ float s[256];
    s[t] = x[row*256+t];
    __syncthreads();
    for (unsigned d = 128; d > 0; d /= 2) {
        if (t < d) s[t] += s[t+d];
        __syncthreads();
    }
    if (t == 0) out[row] = s[0];
}
// Only thread 0 writes the result: no all-thread broadcast is needed.
__global__ void row_sum_shuffle(const float* x, float* out) {
    unsigned t = threadIdx.x;
    unsigned lane = t % 32;
    unsigned warp = t / 32;
    size_t row = blockIdx.x;
    float v = warp_reduce<false>(x[row*256+t]);
    __shared__ float sums[8];
    if (lane == 0) sums[warp] = v;
    __syncthreads();
    if (warp == 0) {
        v = lane < 8 ? sums[lane] : 0.0f;
        for (int d = 4; d > 0; d /= 2)
            v += __shfl_down_sync(0xffffffffu, v, d);
        if (lane == 0) out[row] = v;
    }
}

void run_rows(size_t rows, int repeats) {
    require(rows <= 131072, "rows must be 0..131072; columns are fixed at 256");
    if (!rows) { std::puts("row_reduce,rows=0,cols=256,empty_output=PASS"); return; }
    std::vector<float> x(rows*256);
    std::vector<double> ref(rows,0);
    for (size_t i=0;i<x.size();++i) {
        x[i]=float(int((i*13+7)%101)-50)*0.03125f;
        ref[i/256]+=x[i];
    }
    DeviceBuffer<float> dx(x.size()),out(rows);dx.upload(x);
    auto launch=[&](int mode) {
        if (mode==0) row_sum_shared<<<unsigned(rows),256>>>(dx.p,out.p);
        else row_sum_shuffle<<<unsigned(rows),256>>>(dx.p,out.p);
    };
    for (int mode=0;mode<2;++mode) {
        CUDA_CHECK(cudaMemset(out.p,0xff,rows*sizeof(float)));
        launch(mode);CUDA_CHECK(cudaGetLastError());CUDA_CHECK(cudaDeviceSynchronize());
        check_close(out.download(),ref,1e-4,1e-5);
    }
    std::printf("row_reduce,rows=%zu,cols=256,CPU_reference=PASS\n",rows);
    if (!repeats) return;
    // Warm up each version equally, then alternate AB/BA across batches.
    for (int warm=0;warm<3;++warm) { launch(0);launch(1); }
    CUDA_CHECK(cudaGetLastError());CUDA_CHECK(cudaDeviceSynchronize());
    cudaEvent_t start,stop;
    CUDA_CHECK(cudaEventCreate(&start));CUDA_CHECK(cudaEventCreate(&stop));
    std::array<std::array<float,5>,2> samples{};
    for (int batch=0;batch<5;++batch) {
        for (int slot=0;slot<2;++slot) {
            int mode=(batch+slot)%2;
            CUDA_CHECK(cudaEventRecord(start));
            for (int r=0;r<repeats;++r) launch(mode);
            CUDA_CHECK(cudaGetLastError());CUDA_CHECK(cudaEventRecord(stop));
            CUDA_CHECK(cudaEventSynchronize(stop));
            CUDA_CHECK(cudaEventElapsedTime(&samples[mode][batch],start,stop));
            samples[mode][batch]/=repeats;
        }
    }
    CUDA_CHECK(cudaEventDestroy(start));CUDA_CHECK(cudaEventDestroy(stop));
    for (int mode=0;mode<2;++mode) {
        std::sort(samples[mode].begin(),samples[mode].end());
        std::printf("%s_ms=%.6f\n",mode?"shuffle":"shared",samples[mode][2]);
    }
    std::printf("shuffle_speedup=%.2fx\n",samples[0][2]/samples[1][2]);
}
__global__ void scan_block(const unsigned* x, unsigned* out, unsigned* total, size_t n) {
    __shared__ unsigned s[256];
    unsigned t = threadIdx.x;
    size_t i = size_t(blockIdx.x)*256+t;
    s[t] = i < n ? x[i] : 0;
    __syncthreads();
    for (unsigned d = 1; d < 256; d *= 2) {
        unsigned r = (t+1)*2*d-1;
        if (r < 256) s[r] += s[r-d];
        __syncthreads();
    }
    if (t == 0) { total[blockIdx.x] = s[255]; s[255] = 0; }
    __syncthreads();
    for (unsigned d = 128; d > 0; d /= 2) {
        unsigned r = (t+1)*2*d-1;
        if (r < 256) {
            unsigned left = s[r-d];
            s[r-d] = s[r];
            s[r] += left;
        }
        __syncthreads();
    }
    if (i < n) out[i] = s[t];
}
__global__ void add_offsets(unsigned* out, const unsigned* offsets, size_t n) {
    size_t i = size_t(blockIdx.x)*256+threadIdx.x;
    if (i < n) out[i] += offsets[blockIdx.x];
}
// Allocate all recursion scratch once, outside benchmark. One plan cannot run concurrently.
struct ScanPlan {
    size_t n, blocks;
    DeviceBuffer<unsigned> totals, offsets;
    std::unique_ptr<ScanPlan> next;
    explicit ScanPlan(size_t count)
        : n(count), blocks((n+255)/256),
          totals(blocks), offsets(blocks) {
        if (blocks > 1)
            next = std::make_unique<ScanPlan>(blocks);
    }
    void run(const unsigned* x, unsigned* out) {
        if (!n) return;
        scan_block<<<unsigned(blocks),256>>>(x, out, totals.p, n);
        CUDA_CHECK(cudaGetLastError());
        if (next) {
            next->run(totals.p, offsets.p);
            add_offsets<<<unsigned(blocks),256>>>(out, offsets.p, n);
            CUDA_CHECK(cudaGetLastError());
        }
    }
};
__global__ void hist_global(const unsigned* x, unsigned* hist, size_t n) {
    for (size_t i = size_t(blockIdx.x)*256+threadIdx.x;
         i < n; i += size_t(gridDim.x)*256)
        atomicAdd(&hist[x[i]], 1u);
}
__global__ void hist_shared(const unsigned* x, unsigned* hist, size_t n) {
    __shared__ unsigned local[256];
    local[threadIdx.x] = 0;
    __syncthreads();
    for (size_t i = size_t(blockIdx.x)*256+threadIdx.x;
         i < n; i += size_t(gridDim.x)*256)
        atomicAdd(&local[x[i]], 1u);
    __syncthreads();
    unsigned v = local[threadIdx.x];
    if (v) atomicAdd(&hist[threadIdx.x], v);
}
void run_reduce(size_t n,int repeats){
    std::vector<float>x(n);double sum=0;
    for(size_t i=0;i<n;++i){x[i]=float(int(i%101)-50)*0.03125f;sum+=x[i];}
    unsigned g=unsigned(std::max<size_t>(1,std::min<size_t>((n+255)/256,256)));
    DeviceBuffer<float>dx(n),partial(g),out(1);dx.upload(x);
    for(int mode=0;mode<2;++mode){
        const char* name=mode?"reduce_shuffle":"reduce_shared";
        auto launch=[&]{
            if(!n){out.zero();return;}
            if(mode){reduce_sum<<<g,256>>>(dx.p,partial.p,n);reduce_sum<<<1,256>>>(partial.p,out.p,g);}
            else {reduce_shared<<<g,256>>>(dx.p,partial.p,n);reduce_shared<<<1,256>>>(partial.p,out.p,g);}
        };
        CUDA_CHECK(cudaMemset(out.p,0xff,sizeof(float)));
        launch();CUDA_CHECK(cudaGetLastError());CUDA_CHECK(cudaDeviceSynchronize());
        double error=check_close(out.download(),{sum},1e-4,1e-5);
        std::printf("%s,N=%zu,G=%u,sum=%.9g,max_abs_error=%.5g,PASS\n",name,n,g,sum,error);
        if(repeats){float ms=benchmark(name,launch,repeats);std::printf("RESULT,reduce,%s,%zu,%.6f\n",name,n,ms);}
    }
}
void run_scan(size_t n,int repeats){
    std::vector<unsigned>x(n),ref(n);unsigned sum=0;
    for(size_t i=0;i<n;++i){x[i]=unsigned((i*7)%4);ref[i]=sum;sum+=x[i];}
    DeviceBuffer<unsigned>dx(n),out(n),cub_out(n);dx.upload(x);ScanPlan plan(n);
    if(n)CUDA_CHECK(cudaMemset(out.p,0xff,n*sizeof(unsigned)));
    auto launch=[&]{plan.run(dx.p,out.p);};launch();CUDA_CHECK(cudaDeviceSynchronize());
    require(out.download()==ref,"Hierarchical scan mismatch");std::printf("scan,N=%zu,PASS\n",n);
    if(!n)return;
    size_t bytes=0;CUDA_CHECK(cub::DeviceScan::ExclusiveSum(nullptr,bytes,dx.p,cub_out.p,int(n)));
    DeviceBuffer<unsigned char>temp(bytes);
    auto library=[&]{CUDA_CHECK(cub::DeviceScan::ExclusiveSum(temp.p,bytes,dx.p,cub_out.p,int(n)));};
    library();CUDA_CHECK(cudaDeviceSynchronize());require(cub_out.download()==ref,"CUB scan mismatch");
    std::printf("cub_scan,N=%zu,temp_bytes=%zu,PASS\n",n,bytes);
    if(n<=16){std::printf("input:");for(auto v:x)std::printf(" %u",v);std::printf("\nexclusive:");for(auto v:out.download())std::printf(" %u",v);std::puts("");}
    if(repeats){
        float own=benchmark("hierarchical_scan_all_stages",launch,repeats);
        float cub=benchmark("cub_scan",library,repeats);
        std::printf("RESULT,scan,hierarchical,%zu,%.6f\nRESULT,scan,cub,%zu,%.6f\n",n,own,n,cub);
    }
}
void run_hist(size_t n,int distribution,int repeats){
    std::vector<unsigned>x(n),ref(256,0);
    for(size_t i=0;i<n;++i){x[i]=distribution==0?unsigned(i%256):distribution==1?(i%10?0:unsigned(i%256)):0;++ref[x[i]];}
    DeviceBuffer<unsigned>dx(n),out(256);dx.upload(x);
    unsigned g=unsigned(std::max<size_t>(1,std::min<size_t>((n+255)/256,256)));
    for(int mode=0;mode<2;++mode){auto launch=[&]{out.zero();if(n){if(mode)hist_shared<<<g,256>>>(dx.p,out.p,n);else hist_global<<<g,256>>>(dx.p,out.p,n);}};
        launch();CUDA_CHECK(cudaGetLastError());CUDA_CHECK(cudaDeviceSynchronize());auto got=out.download();
        require(got==ref,"Histogram mismatch");require(std::accumulate(got.begin(),got.end(),size_t(0))==n,"Histogram count not conserved");
        std::printf("histogram,N=%zu,distribution=%d,mode=%d,PASS\n",n,distribution,mode);
        if(repeats){float ms=benchmark(mode?"hist_shared_including_clear":"hist_global_including_clear",launch,repeats);std::printf("RESULT,hist,%s,%zu,%d,%.6f\n",mode?"shared":"global",n,distribution,ms);}
    }
}

__global__ void mark_positive(const int* x, unsigned* flag, size_t n) {
    size_t i = size_t(blockIdx.x)*256+threadIdx.x;
    if (i < n) flag[i] = x[i] > 0 ? 1u : 0u;
}
__global__ void scatter_positive(const int* x, const unsigned* flag,
                                 const unsigned* pos, int* out, unsigned* count, size_t n) {
    size_t i = size_t(blockIdx.x)*256+threadIdx.x;
    if (i < n && flag[i]) out[pos[i]] = x[i];
    if (i == 0) *count = pos[n-1]+flag[n-1]; // Host only launches this for n>0.
}
void run_compact(size_t n,int repeats,int pattern=0){
    std::vector<int>x(n),ref;
    for(size_t i=0;i<n;++i){x[i]=pattern==1?-1:pattern==2?1:int(i%17)-8;if(x[i]>0)ref.push_back(x[i]);}
    DeviceBuffer<int>dx(n),out(n);DeviceBuffer<unsigned>flag(n),pos(n),count(1);
    dx.upload(x);ScanPlan plan(n);unsigned g=unsigned((n+255)/256);
    auto launch=[&]{
        if(!n){count.zero();return;}
        mark_positive<<<g,256>>>(dx.p,flag.p,n);
        plan.run(flag.p,pos.p);
        scatter_positive<<<g,256>>>(dx.p,flag.p,pos.p,out.p,count.p,n);
    };
    if(n)CUDA_CHECK(cudaMemset(out.p,0xff,n*sizeof(int)));
    launch();CUDA_CHECK(cudaGetLastError());CUDA_CHECK(cudaDeviceSynchronize());
    unsigned kept=count.download()[0];require(kept==ref.size(),"Compaction count mismatch");
    auto got=out.download();got.resize(kept);require(got==ref,"Stable compaction order/value mismatch");
    std::printf("compact,N=%zu,pattern=%d,kept=%u,stable_order=PASS\n",n,pattern,kept);
    if(n<=17){std::printf("input:");for(auto v:x)std::printf(" %d",v);std::printf("\npositive:");for(auto v:got)std::printf(" %d",v);std::puts("");}
    if(repeats){float ms=benchmark("compact_mark_scan_scatter",launch,repeats);std::printf("RESULT,compact,mark_scan_scatter,%zu,%.6f\n",n,ms);}
}
int number(const char* text,int low,int high){
    char* end=nullptr;errno=0;long v=std::strtol(text,&end,10);
    require(errno==0&&end!=text&&!*end&&v>=low&&v<=high,"Invalid argument: N 0..16777216, repeats 1..1000");return int(v);
}
int main(int argc,char** argv){
    if(argc==2&&!std::strcmp(argv[1],"--help")){
        std::puts("primitives.exe [reduce|scan|compact|hist|all] [N [repeats]] | --check-only\nprimitives.exe rows [row_count [repeats]]\nDefaults: all 1048576 20; N 0..16777216; repeats 1..1000\nrows: standalone experiment, default 32768 rows, 0..131072 rows, exactly 256 columns\nhist distributions: 0=cyclic uniform, 1=about 90% bin0, 2=all bin0\nTiming includes all GPU stages (histogram includes clearing); allocation and copies excluded.");return 0;
    }
    bool checks=argc==2&&!std::strcmp(argv[1],"--check-only");
    require(argc<=4,"Use --help for arguments");
    const char* task=argc>=2?argv[1]:"all";
    bool rows_task=!std::strcmp(task,"rows");
    require(checks||rows_task||!std::strcmp(task,"all")||!std::strcmp(task,"reduce")||!std::strcmp(task,"scan")||!std::strcmp(task,"compact")||!std::strcmp(task,"hist"),"Unknown task; use --help");
    size_t n=argc>=3?size_t(number(argv[2],0,1<<24)):(rows_task?size_t(32768):size_t(1<<20));
    int repeats=argc>=4?number(argv[3],1,1000):20;
    device_info();
    if(checks){
        for (size_t rows:{size_t(0),size_t(1),size_t(7),size_t(33),size_t(257),size_t(4097)}) run_rows(rows,0);
        for(size_t size:{size_t(0),size_t(1),size_t(31),size_t(33),size_t(255),size_t(256),size_t(257),size_t(1003),size_t(65537)}){
            run_reduce(size,0);run_scan(size,0);
            for(int d=0;d<3;++d){run_hist(size,d,0);run_compact(size,0,d);}
        }
        return 0;
    }
    if (rows_task) { run_rows(n,repeats); return 0; }
    bool all=!std::strcmp(task,"all");
    if(all||!std::strcmp(task,"reduce"))run_reduce(n,repeats);
    if(all||!std::strcmp(task,"scan"))run_scan(n,repeats);
    if(all||!std::strcmp(task,"compact"))run_compact(n,repeats);
    if(all||!std::strcmp(task,"hist"))for(int d=0;d<3;++d)run_hist(n,d,repeats);
}

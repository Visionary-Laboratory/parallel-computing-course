"""Simple custom-operator round trip. CPU reference requires only PyTorch.
CUDA option builds our own kernel with nvcc and ninja. No silent CPU fallback.
"""
import argparse
import os
from pathlib import Path
import statistics
import time
import torch

# 1. Schema: no input mutation and no output alias.
lib = torch.library.Library("course", "DEF")
lib.define("affine(Tensor x) -> Tensor")

def contract(x):
    allowed = (torch.float32, torch.float64) if x.device.type == "cpu" else (torch.float32,)
    torch._check(x.device.type in ("cpu", "cuda"))
    torch._check(x.dtype in allowed)
    torch._check(x.is_contiguous())

# CPU is an ATen reference, not a simulation of CUDA or its performance.
@torch.library.impl(lib, "affine", "CPU")
def affine_cpu(x):
    contract(x)
    return 2*x+1

# 2. Metadata propagation, without inspecting tensor values.
@torch.library.register_fake("course::affine")
def affine_fake(x):
    contract(x)
    return torch.empty_like(x)

# 3. VJP: no saved forward input is needed. Built-in ops handle strided grad_out.
def backward(ctx, grad_out):
    return 2*grad_out

torch.library.register_autograd("course::affine", backward)
affine = torch.ops.course.affine.default

def check(device):
    torch.manual_seed(2026)
    for shape in ((0,), (), (1,), (257,), (3,5)):
        x=torch.randn(shape, device=device, requires_grad=True)
        torch.testing.assert_close(affine(x), 2*x+1)
        grad=torch.randn_like(x)
        actual,=torch.autograd.grad(affine(x), x, grad)
        torch.testing.assert_close(actual, 2*grad)
        # Integration/schema test; this is not a numerical derivative test.
        torch.library.opcheck(affine, (x,))
    for bad in (torch.ones(3, dtype=torch.int32, device=device),
                torch.ones((3,5),device=device).T):
        try:
            affine(bad)
        except RuntimeError:
            pass
        else:
            raise AssertionError("invalid input was accepted")
    # Independent numerical check in double precision on CPU.
    x=torch.randn(4,dtype=torch.float64,requires_grad=True)
    assert torch.autograd.gradcheck(affine,(x,))
    # 4. Put the operator after an ordinary linear layer; compare every gradient.
    layer=torch.nn.Linear(3,2).to(device)
    x=torch.randn(5,3,device=device,requires_grad=True)
    targets=(x,*layer.parameters())
    ours=affine(layer(x)).square().mean()
    reference=(2*layer(x)+1).square().mean()
    torch.testing.assert_close(ours,reference)
    for a,b in zip(torch.autograd.grad(ours,targets),torch.autograd.grad(reference,targets)):
        torch.testing.assert_close(a,b)
    print("PASS: forward, contract, opcheck, VJP, CPU gradcheck, model gradients")

def benchmark(device):
    def sync():
        if device == 'cuda': torch.cuda.synchronize()
    for n in (257, 1<<20):
        x=torch.randn(n,device=device)
        for label, fn in (("custom",lambda:affine(x)),("ATen",lambda:2*x+1)):
            for _ in range(10): fn()
            samples=[]
            for _ in range(5):
                sync(); start=time.perf_counter()
                for _ in range(100): result=fn()
                sync(); samples.append((time.perf_counter()-start)*1e6/100)
            torch.testing.assert_close(result,2*x+1)
            print(dict(n=n,implementation=label,scope='warm Python call incl allocation, no H2D/D2H',
                       median_us=statistics.median(samples),min_us=min(samples),max_us=max(samples)))

def load_cuda(verbose=False):
    if not torch.cuda.is_available(): raise RuntimeError('CUDA requested but unavailable')
    from torch.utils import cpp_extension
    local_tools=Path(__file__).parent / '.tools' / 'bin'
    if local_tools.is_dir():
        os.environ['PATH']=str(local_tools)+os.pathsep+os.environ.get('PATH','')
    # PyTorch 2.11 uses OEM decoding for compiler output on Windows.
    # This classroom toolchain emits UTF-8; this affects diagnostics only,
    # and keeps the compiler version/ABI checks enabled.
    if os.name == 'nt':
        cpp_extension.SUBPROCESS_DECODE_ARGS = ('utf-8', 'replace')
        # The classroom terminal already inherited vcvars64.bat.
        if os.environ.get('VSCMD_ARG_TGT_ARCH'):
            os.environ.setdefault('DISTUTILS_USE_SDK','1')
    build_dir=Path(__file__).parent / '.build'
    build_dir.mkdir(exist_ok=True)
    cpp_extension.load(name='course_affine_cuda',sources=[str(Path(__file__).with_suffix('.cu'))],
         is_python_module=False,build_directory=str(build_dir),
         extra_cuda_cflags=['-O3']+(['-Xcompiler','/utf-8'] if os.name=='nt' else []),verbose=verbose)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--cuda',action='store_true');parser.add_argument('--benchmark',action='store_true')
    args=parser.parse_args();device='cuda' if args.cuda else 'cpu'
    if args.cuda: load_cuda(verbose=True)
    print('PyTorch',torch.__version__,'device',device,'CUDA build',torch.version.cuda)
    if args.cuda: print(torch.cuda.get_device_name(),torch.cuda.get_device_capability())
    check(device)
    if args.benchmark: benchmark(device)

if __name__=='__main__': main()

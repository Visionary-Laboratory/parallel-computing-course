// Course example: y = 2*x + 1. Registered schema lives in affine.py.
#include <torch/library.h>
#include <algorithm>
#include <ATen/ATen.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
__global__ void affine_kernel(const float* x, float* y, int64_t n) {
  for (int64_t i = int64_t(blockIdx.x)*blockDim.x+threadIdx.x;
       i<n; i+=int64_t(blockDim.x)*gridDim.x) y[i]=2.0f*x[i]+1.0f;
}
at::Tensor affine_cuda(const at::Tensor& x) {
  TORCH_CHECK(x.is_cuda() && x.scalar_type()==at::kFloat && x.is_contiguous(),
              "course::affine CUDA requires contiguous float32 input");
  c10::cuda::CUDAGuard guard(x.device());
  auto y=at::empty(x.sizes(), x.options());
  const int64_t n=x.numel();
  if(n) {
    const int blocks=int(std::min<int64_t>((n+255)/256,4096));
    affine_kernel<<<blocks,256,0,at::cuda::getCurrentCUDAStream()>>>(
      x.data_ptr<float>(), y.data_ptr<float>(), n);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
  }
  return y;
}
TORCH_LIBRARY_IMPL(course, CUDA, m) { m.impl("affine", &affine_cuda); }

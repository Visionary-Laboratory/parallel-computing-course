"""Optimize a three-element CUDA input through our registered affine operator.

This is a teaching demo, not a benchmark: printing synchronizes with the GPU.
The CUDA forward is ours; PyTorch supplies the loss, backward and update ops.
"""
import torch
from affine import affine, load_cuda


def show(step, x, y, loss):
    # One row describes the state AFTER exactly `step` updates.
    xs = [round(value, 4) for value in x.detach().cpu().tolist()]
    ys = [round(value, 4) for value in y.detach().cpu().tolist()]
    print(f"{step:>4}  x={str(xs):<28} y={str(ys):<28} loss={loss.item():.6g}")


def main():
    load_cuda()
    x = torch.zeros(3, device="cuda", requires_grad=True)
    target = torch.tensor([7., -3., 5.], device="cuda")
    lr = 0.1
    print("GPU:", torch.cuda.get_device_name())
    print("target =", target.cpu().tolist())
    print("step = completed updates; loss = 0.5 * sum((y-target)^2)")

    for step in range(20):
        x.grad = None  # Clear the old gradient; backward otherwise accumulates.
        y = affine(x)  # Our CUDA kernel computes the entire vector.
        loss = 0.5 * (y - target).square().sum()  # One scalar loss.
        loss.backward()  # Loss -> y -> our registered backward -> x.grad.
        # Independent chain-rule check for this particular loss.
        torch.testing.assert_close(x.grad, 2 * (y.detach() - target))
        if step in (0, 1, 2, 5, 10):
            show(step, x, y, loss)
        with torch.no_grad():  # Do not differentiate through the update itself.
            x -= lr * x.grad

    # Recompute y and loss so the final row uses the UPDATED x.
    with torch.no_grad():
        y = affine(x)
        loss = 0.5 * (y - target).square().sum()
    show(20, x, y, loss)
    torch.testing.assert_close(x, (target - 1) / 2, rtol=0, atol=2e-4)
    torch.testing.assert_close(y, target, rtol=0, atol=3e-4)
    assert loss.item() < 1e-6
    print("PASS: vector gradients checked; x approaches [3, -2, 2].")


if __name__ == "__main__":
    main()

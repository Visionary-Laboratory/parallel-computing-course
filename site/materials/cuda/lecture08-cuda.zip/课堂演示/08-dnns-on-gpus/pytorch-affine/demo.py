"""Classroom: one forward call and one explicit upstream gradient."""
import torch
from affine import affine, load_cuda

load_cuda()
x = torch.tensor([-2., 0., 3.], device="cuda", requires_grad=True)
y = affine(x)
g = torch.tensor([1., 2., -1.], device="cuda")
y.backward(g)
torch.testing.assert_close(y, 2*x+1)
torch.testing.assert_close(x.grad, 2*g)
print("x =", x.detach().cpu().tolist())
print("y =", y.detach().cpu().tolist())
print("upstream g =", g.cpu().tolist())
print("dx =", x.grad.cpu().tolist())
print("PASS: y=2*x+1, dx=2*g")

#include "lab08_utils.cuh"
#include <cublas_v2.h>
inline void cublas_check(cublasStatus_t s,const char* file,int line){if(s!=CUBLAS_STATUS_SUCCESS){std::fprintf(stderr,"%s:%d cuBLAS status=%d\n",file,line,int(s));std::exit(EXIT_FAILURE);}}
#define CUBLAS_CHECK(expr) cublas_check((expr),__FILE__,__LINE__)
constexpr int T = 16;  // Output tile: T rows by T columns; block(T, T).
constexpr int TK = 16; // Number of K terms loaded and accumulated per stage.
// This teaching version loads one A and one B element per thread.
static_assert(T == TK, "The one-element-per-thread loader requires T == TK.");
__global__ void gemm_naive(const float* A, const float* B, float* C, int M, int N, int K) {
    int row = blockIdx.y * T + threadIdx.y, col = blockIdx.x * T + threadIdx.x;
    if (row < M && col < N) {
        float acc = 0;
        for (int k = 0; k < K; ++k)
            acc = fmaf(A[size_t(row) * K + k], B[size_t(k) * N + col], acc);
        C[size_t(row) * N + col] = acc;
    }
}
__global__ void gemm_tiled(const float* A, const float* B, float* C, int M, int N, int K) {
    __shared__ float As[T][TK], Bs[TK][T];
    int tx = threadIdx.x, ty = threadIdx.y;
    int row = blockIdx.y * T + ty, col = blockIdx.x * T + tx;
    float acc = 0;
    for (int base = 0; base < K; base += TK) { // base: this stage's starting K index.
        As[ty][tx] = (row < M && base + tx < K) ? A[size_t(row) * K + base + tx] : 0.0f;
        Bs[ty][tx] = (base + ty < K && col < N) ? B[size_t(base + ty) * N + col] : 0.0f;
        __syncthreads(); // This stage's inputs are ready.
        for (int k = 0; k < TK; ++k) // Local K index; global K index is base + k.
            acc = fmaf(As[ty][k], Bs[k][tx], acc);
        __syncthreads(); // All readers finish before the next stage overwrites the tile.
    }
    if (row < M && col < N) C[size_t(row) * N + col] = acc;
}
void run(int M,int N,int K,int repeats=0){
    if(!M||!N){std::puts("Empty GEMM output: launch skipped; PASS");return;}
    std::vector<float>A(size_t(M)*K),B(size_t(K)*N);std::vector<double>ref(size_t(M)*N,0);
    for(size_t i=0;i<A.size();++i)A[i]=float(int(i%29)-14)/17.0f;
    for(size_t i=0;i<B.size();++i)B[i]=float(int(i%31)-15)/19.0f;
    for(int r=0;r<M;++r)for(int k=0;k<K;++k)for(int c=0;c<N;++c)ref[size_t(r)*N+c]+=double(A[size_t(r)*K+k])*double(B[size_t(k)*N+c]);
    DeviceBuffer<float>da(A.size()),db(B.size()),dc(ref.size());da.upload(A);db.upload(B);
    cublasHandle_t handle;CUBLAS_CHECK(cublasCreate(&handle));
    CUBLAS_CHECK(cublasSetMathMode(handle,CUBLAS_PEDANTIC_MATH));
    dim3 block(T,T),grid((N+T-1)/T,(M+T-1)/T);float alpha=1,beta=0;
    for(int mode=0;mode<3;++mode){
        const char* name=mode==0?"gemm_naive_fp32":mode==1?"gemm_tiled16_fp32":"cublas_sgemm_pedantic";
        auto launch=[&]{
            if(K==0){dc.zero();return;}
            if(mode==0)gemm_naive<<<grid,block>>>(da.p,db.p,dc.p,M,N,K);
            if(mode==1)gemm_tiled<<<grid,block>>>(da.p,db.p,dc.p,M,N,K);
            // Row-major C=AB is column-major C^T=B^T A^T, with swapped M/N.
            if(mode==2)CUBLAS_CHECK(cublasSgemm(handle,CUBLAS_OP_N,CUBLAS_OP_N,N,M,K,&alpha,db.p,N,da.p,K,&beta,dc.p,N));
        };
        CUDA_CHECK(cudaMemset(dc.p,0xff,ref.size()*sizeof(float)));
        launch();CUDA_CHECK(cudaGetLastError());CUDA_CHECK(cudaDeviceSynchronize());
        double err=check_close(dc.download(),ref,2e-4,2e-4);
        std::printf("%s,M=%d,N=%d,K=%d,max_error=%.5g,PASS\n",name,M,N,K,err);
        if(repeats){float ms=benchmark(name,launch,repeats);std::printf("RESULT,%s,M=%d,N=%d,K=%d,median_ms=%.6f\n",name,M,N,K,ms);std::printf("GFLOPs_per_second=%.3f (2MNK convention)\n",2.0*M*N*K/(ms*1e6));}
    }
    CUBLAS_CHECK(cublasDestroy(handle));
}
int main(int argc,char** argv){
    if(argc==2 && !std::strcmp(argv[1],"--help")){
        std::puts("gemm.exe [M N K [repeats]] | --check-only; dimensions 0..1024, repeats 1..1000");return 0;
    }
    device_info();
    if(argc==2 && !std::strcmp(argv[1],"--check-only")){
        const std::array<int,3> cases[]={{0,7,3},{7,0,3},{1,1,1},{3,5,0},{17,33,19},{63,65,31},{1,127,65}};
        for(auto d:cases)run(d[0],d[1],d[2]);return 0;
    }
    require(argc==1||argc==4||argc==5,"Usage: gemm.exe [M N K [repeats]] | --check-only");
    int M=argc>=4?lab08_int(argv[1],0,1024):512,N=argc>=4?lab08_int(argv[2],0,1024):512;
    int K=argc>=4?lab08_int(argv[3],0,1024):512,repeats=argc==5?lab08_int(argv[4],1,1000):20;
    std::puts("FP32; cuBLAS PEDANTIC; warm-up 3, 5 batches; allocation/copies/CPU reference outside timing.");
    run(M,N,K,repeats);
}

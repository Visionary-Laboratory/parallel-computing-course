#include "lab08_utils.cuh"
// Finite, nonempty rows, 1<=cols<=1024. Exactly 256 threads own each complete row.
__global__ void softmax_rows(const float* x, float* y, int cols) {
    float v[4], local_max = -CUDART_INF_F;
    #pragma unroll
    for (int k = 0; k < 4; ++k) {
        int c = threadIdx.x + 256*k;
        v[k] = c < cols ? x[size_t(blockIdx.x)*cols+c] : -CUDART_INF_F;
        local_max = fmaxf(local_max, v[k]);
    }
    float row_max = block_reduce<true>(local_max), local_sum = 0;
    #pragma unroll
    for (int k = 0; k < 4; ++k) {
        v[k] = expf(v[k] - row_max);
        local_sum += v[k];
    }
    float row_sum = block_reduce<false>(local_sum);
    #pragma unroll
    for (int k = 0; k < 4; ++k) {
        int c = threadIdx.x + 256*k;
        if (c < cols) y[size_t(blockIdx.x)*cols+c] = v[k] / row_sum;
    }
}
// Three launches, with row scalars and elementwise intermediates in global memory.
__global__ void row_max(const float* x, float* maximum, int cols) {
    float m = -CUDART_INF_F;
    for (int c = threadIdx.x; c < cols; c += 256)
        m = fmaxf(m, x[size_t(blockIdx.x)*cols+c]);
    m = block_reduce<true>(m);
    if (threadIdx.x == 0) maximum[blockIdx.x] = m;
}
__global__ void row_exp_sum(const float* x, const float* maximum,
                           float* e, float* sums, int cols) {
    float sum = 0, m = maximum[blockIdx.x];
    for (int c = threadIdx.x; c < cols; c += 256) {
        size_t i = size_t(blockIdx.x)*cols+c;
        float v = expf(x[i]-m);
        e[i] = v; sum += v;
    }
    sum = block_reduce<false>(sum);
    if (threadIdx.x == 0) sums[blockIdx.x] = sum;
}
__global__ void row_normalize(const float* e, const float* sums, float* y, int cols) {
    float sum = sums[blockIdx.x];
    for (int c = threadIdx.x; c < cols; c += 256) {
        size_t i = size_t(blockIdx.x)*cols+c;
        y[i] = e[i]/sum;
    }
}
void run(int rows,int cols,int repeats=0){
    require(rows>=0&&cols>=1&&cols<=1024,"Softmax requires rows>=0, 1<=cols<=1024");
    std::vector<float>x(size_t(rows)*cols);std::vector<double>ref(x.size());
    for(int r=0;r<rows;++r){
        for(int c=0;c<cols;++c)x[size_t(r)*cols+c]=float((c*17+r*7)%67-33)*0.25f+(r%3==0?1000.0f:r%3==1?-1000.0f:0.0f);
        double m=-std::numeric_limits<double>::infinity(),sum=0;
        for(int c=0;c<cols;++c)m=std::max(m,double(x[size_t(r)*cols+c]));
        for(int c=0;c<cols;++c){ref[size_t(r)*cols+c]=std::exp(double(x[size_t(r)*cols+c])-m);sum+=ref[size_t(r)*cols+c];}
        for(int c=0;c<cols;++c)ref[size_t(r)*cols+c]/=sum;
    }
    if(!rows){std::puts("Zero Softmax rows: launch skipped; PASS");return;}
    DeviceBuffer<float>dx(x.size()),dy(x.size()),de(x.size()),dm(rows),ds(rows);dx.upload(x);
    for(int mode=0;mode<2;++mode){
        const char* name=mode==0?"softmax_three_kernels":"softmax_fused_row";
        auto launch=[&]{
            if(mode==0){
                row_max<<<rows,256>>>(dx.p,dm.p,cols);
                row_exp_sum<<<rows,256>>>(dx.p,dm.p,de.p,ds.p,cols);
                row_normalize<<<rows,256>>>(de.p,ds.p,dy.p,cols);
            }else softmax_rows<<<rows,256>>>(dx.p,dy.p,cols);
        };
        CUDA_CHECK(cudaMemset(dy.p,0xff,dy.n*sizeof(float)));
        launch();CUDA_CHECK(cudaGetLastError());CUDA_CHECK(cudaDeviceSynchronize());auto got=dy.download();
        double err=check_close(got,ref,1e-6,1e-5);
        for(int r=0;r<rows;++r){double sum=0;for(int c=0;c<cols;++c){float v=got[size_t(r)*cols+c];require(v>=0&&v<=1,"Invalid probability");sum+=v;}require(std::abs(sum-1)<2e-5,"Probability sum differs from one");}
        std::printf("%s,rows=%d,cols=%d,max_error=%.5g,PASS\n",name,rows,cols,err);
        if(repeats){float ms=benchmark(name,launch,repeats);std::printf("RESULT,%s,rows=%d,cols=%d,median_ms=%.6f\n",name,rows,cols,ms);}
    }
}
int main(int argc,char** argv){
    if(argc==2 && !std::strcmp(argv[1],"--help")){
        std::puts("softmax.exe [rows cols [repeats]] | --check-only; rows 0..65536, cols 1..1024, repeats 1..1000");return 0;
    }
    device_info();
    if(argc==2 && !std::strcmp(argv[1],"--check-only")){
        run(0,17);for(int c:{1,31,32,33,255,256,257,1003,1024})run(7,c);return 0;
    }
    require(argc==1||argc==3||argc==4,"Usage: softmax.exe [rows cols [repeats]] | --check-only");
    int rows=argc>=3?lab08_int(argv[1],0,65536):4096,cols=argc>=3?lab08_int(argv[2],1,1024):1003;
    int repeats=argc==4?lab08_int(argv[3],1,1000):20;
    std::puts("FP32 finite logits; warm-up 3, 5 batches; all three baseline launches timed together; allocations/copies excluded.");
    run(rows,cols,repeats);
}

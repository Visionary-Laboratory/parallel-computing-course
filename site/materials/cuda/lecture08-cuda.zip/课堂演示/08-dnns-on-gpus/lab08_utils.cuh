#pragma once
#include "common.cuh"
#include <cerrno>
#include <cstring>
// Host argument parsing; not part of a kernel.
inline int lab08_int(const char* text, int low, int high) {
    char* end=nullptr; errno=0;
    long value=std::strtol(text,&end,10);
    require(errno==0 && end!=text && *end=='\0' && value>=low && value<=high,
            "Invalid argument (see --help for supported ranges).");
    return int(value);
}

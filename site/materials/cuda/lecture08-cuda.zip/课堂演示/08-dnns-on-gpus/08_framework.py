"""Compare eager expressions with torch.softmax; see the lecture for timing scope."""
import argparse
import statistics
import torch

def explicit_softmax(x):
    shifted = x - x.amax(dim=-1, keepdim=True)
    e = shifted.exp()
    return e / e.sum(dim=-1, keepdim=True)

def measure(name, fn, x, ref, repeats):
    torch.testing.assert_close(fn(x), ref, atol=1e-6, rtol=1e-5)
    for _ in range(10):
        fn(x)
    torch.cuda.synchronize()
    times = []
    for _ in range(5):
        start, stop = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
        start.record()
        for _ in range(repeats):
            y = fn(x)
        stop.record()
        stop.synchronize()
        times.append(start.elapsed_time(stop) / repeats)
    torch.testing.assert_close(y, ref, atol=1e-6, rtol=1e-5)
    print(f"{name},shape={tuple(x.shape)},min_ms={min(times):.6f},"
          f"median_ms={statistics.median(times):.6f},max_ms={max(times):.6f},PASS")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--compile", action="store_true", help="Also run torch.compile; compilation excluded from stable timing")
    parser.add_argument("--rows", type=int, default=4096)
    parser.add_argument("--cols", type=int, default=1003)
    parser.add_argument("--repeats", type=int, default=50)
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    if not (1 <= args.rows <= 65536 and 1 <= args.cols <= 1024 and 1 <= args.repeats <= 1000):
        parser.error("rows 1..65536, cols 1..1024, repeats 1..1000")
    if not torch.cuda.is_available():
        raise SystemExit("A CUDA-enabled PyTorch installation and NVIDIA GPU are required.")
    print(f"torch={torch.__version__},CUDA={torch.version.cuda},device={torch.cuda.get_device_name(0)}")
    print(f"FP32, finite logits, CUDA events, warm-up 10, 5 batches x {args.repeats} calls; includes output allocation and GPU idle gaps between Python submissions; no transfers.")
    torch.manual_seed(17)
    variants = [("explicit_eager", explicit_softmax), ("torch_softmax", lambda x: torch.softmax(x, dim=-1))]
    if args.compile:
        variants.append(("compiled_explicit", torch.compile(explicit_softmax)))
    with torch.inference_mode():
        shapes = [(7,c) for c in (1,31,32,33,255,256,257,1003,1024)] if args.check_only else [(args.rows,args.cols)]
        for rows, cols in shapes:
            r = torch.arange(rows).unsqueeze(1)
            c = torch.arange(cols).unsqueeze(0)
            cpu = ((c*17+r*7)%67-33).float()*0.25 + torch.where(r%3==0,1000.,torch.where(r%3==1,-1000.,0.))
            x = cpu.cuda()
            ref = torch.softmax(cpu.double(), dim=-1).float().cuda()
            for name, fn in variants:
                if args.check_only:
                    torch.testing.assert_close(fn(x),ref,atol=1e-6,rtol=1e-5)
                    print(f"{name},shape={tuple(x.shape)},CPU_FP64_reference,PASS")
                else:
                    measure(name, fn, x, ref, args.repeats)

if __name__ == "__main__":
    main()
